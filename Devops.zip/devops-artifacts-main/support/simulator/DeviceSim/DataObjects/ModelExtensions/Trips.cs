﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeviceSim.EDataObjects.Models
{
    public partial class Trips
    {
        //public IList<TripPoints> Points { get; set; }
    }
}
